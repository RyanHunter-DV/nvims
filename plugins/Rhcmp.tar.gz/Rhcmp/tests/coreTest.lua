package.path=package.path..';/Users/ryanhunter/project/local/nvims/?.lua';
vim.cmd[[autocmd! ___cmp___]]
local cmp = require('Rhcmp.init');
cmp.setup({});
