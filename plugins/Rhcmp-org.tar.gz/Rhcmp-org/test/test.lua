package.path=package.path..';../?.lua';
vim.cmd [[autocmd!___cmp___]]
cmp = require('init');
cmp.setup({});
