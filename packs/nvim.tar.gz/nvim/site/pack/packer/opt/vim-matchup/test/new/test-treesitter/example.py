def F(x, y):
  if x == 1:
    return 1
  elif x == 2:
    if y == 5:
      pass
    elif y == 7:
      return 9
    else:
      return x
  else:
    return 3
  return 2
