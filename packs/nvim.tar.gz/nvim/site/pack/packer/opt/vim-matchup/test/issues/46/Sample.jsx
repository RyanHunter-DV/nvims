
const Sample = <Sample prop='highlight test'>
  some body
</Sample>;

