// 404 page
export default () => (
  <div>404</div>
)

