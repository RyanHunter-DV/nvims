---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

- Please read through [this section](https://github.com/haorenW1025/completion-nvim/wiki/trouble-shooting) before posting a bug report.

**My testing minimal init.vim**
Post your init.vim to help me reproduce this issue

**How to reproduce**
Detailed step to reproduce this issue.

**Expected behavior**
A clear and concise description of what you expected to happen.
