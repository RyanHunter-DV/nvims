--  Theme: zephyr
--  Author: Glepnir
--  License: MIT
--  Source: http://github.com/glepnir/zephyr-nvim

require("zephyr")
