-- if vim.api.nvim_buf_get_option(0,'filetype')=='ruby' then
-- end
require('snippets.ruby')
require('snippets.uvm')
