-- vim.cmd([[ colorschem nord ]])
vim.cmd([[ colorschem nordfox ]])
--vim.cmd([[ colorschem slate ]])
-- vim.cmd([[ colorschem zephyr ]])
