require("colorbuddy").colorscheme("colorbuddy")
