require("colorbuddy").setup()

-- Run this line to turn function calls yellow
Group.new('luaFunctionCall', c.yellow)

-- Run this line to turn function calls blue
Group.new('luaFunctionCall', c.blue)
