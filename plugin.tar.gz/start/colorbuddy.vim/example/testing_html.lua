
local html = require('colorbuddy.lua_html.init')
local attrs = html.syntax_attributes

print(attrs['comment']['bg'])
