-- stores the list of namespaces
return {}
